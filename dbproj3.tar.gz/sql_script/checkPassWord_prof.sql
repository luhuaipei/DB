SELECT Password FROM faculty where Id = '[';
