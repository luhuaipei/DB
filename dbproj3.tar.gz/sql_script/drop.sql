call dropClass([,']','?','$');
