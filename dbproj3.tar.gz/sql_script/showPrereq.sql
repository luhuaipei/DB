select PrereqUoSCode,UoSName from requires Join unitofstudy Using(UoSCode)
where UoSCode = '[';
