call enroll([,']','?','$',@pre)

