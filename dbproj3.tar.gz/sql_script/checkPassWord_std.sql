SELECT Password FROM student where Id = [;
