SELECT UoSCode,Semester,Year,Grade  FROM transcript Where StudId=[
order by Semester ASC,Year ASC;
