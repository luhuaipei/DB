Delimiter //
SET @pre = 0;
CALL enroll(3213,'','%s','%s',@pre);
select @pre;
//
Delimiter ;
~            
