select Id,Name,Address from student Where Id = [;
