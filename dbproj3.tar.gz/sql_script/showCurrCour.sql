SELECT * FROM transcript WHERE StudId=[ AND  Semester=']' AND Year = ?;
