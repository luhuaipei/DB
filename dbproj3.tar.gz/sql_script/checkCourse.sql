select Grade from transcript where StudId = [
AND UoSCode =  ']' 
AND Year = '?'; 
